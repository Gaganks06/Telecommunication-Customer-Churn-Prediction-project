import streamlit as st
import pandas as pd
import joblib
from pathlib import Path
import numpy as np
from sklearn.pipeline import Pipeline

# Streamlit Page Setup
st.set_page_config(page_title="Telecommunication Churn Prediction", layout="centered")
st.title("Telecommunication Customer Churn Prediction")

# Load Model
MODEL_PATH = Path("best_churn_model.pkl")
if not MODEL_PATH.exists():
    st.error("Model file 'best_churn_model.pkl' not found.")
    st.stop()

try:
    loaded_obj = joblib.load(MODEL_PATH)
except Exception as e:
    st.error(f"Error loading model file: {e}")
    st.stop()

# Support either a raw model or dict-bundle containing model + feature_list
if isinstance(loaded_obj, dict):
    model = loaded_obj.get("model", None)
    feature_list = loaded_obj.get("feature_list", []) or []
else:
    model = loaded_obj
    feature_list = []

if model is None:
    st.error("No valid model found in the file.")
    st.stop()

# Normalize feature_list to a plain Python list
try:
    if hasattr(feature_list, "tolist"):
        feature_list = list(feature_list.tolist())
    else:
        feature_list = list(feature_list)
except Exception:
    feature_list = list(feature_list) if isinstance(feature_list, (list, tuple)) else []

# If model is a Pipeline, attempt to extract preprocessor and final estimator
preproc = None
clf = None
if isinstance(model, Pipeline):
    steps = dict(model.steps)
    preproc = steps.get("preproc", None)
    clf = steps.get("clf", None)
    if preproc is None and len(model.steps) >= 1:
        preproc = model.steps[0][1]
    if clf is None and len(model.steps) >= 1:
        clf = model.steps[-1][1]

# ---------- Streamlit Inputs ----------
st.header("Enter Customer Details")

states = sorted([
    'AK', 'AL', 'AR', 'AZ', 'CA', 'CO', 'CT', 'DC', 'DE', 'FL', 'GA', 'HI', 'IA', 'ID', 'IL', 'IN',
    'KS', 'KY', 'LA', 'MA', 'MD', 'ME', 'MI', 'MN', 'MO', 'MS', 'MT', 'NC', 'ND', 'NE', 'NH', 'NJ',
    'NM', 'NV', 'NY', 'OH', 'OK', 'OR', 'PA', 'RI', 'SC', 'SD', 'TN', 'TX', 'UT', 'VA', 'VT', 'WA',
    'WI', 'WV', 'WY'
])

state = st.selectbox("State", states)
account_length = st.slider("Account Length (days)", 0, 250, 100)
area_code = st.selectbox("Area Code", ["408", "415", "510"])
voice_plan = st.selectbox("Voice Mail Plan", ["yes", "no"])
voice_messages = st.slider("Number of Voice Mail Messages", 0, 60, 10)
intl_plan = st.selectbox("International Plan", ["yes", "no"])
intl_mins = st.number_input("International Minutes", 0.0, 300.0, 10.0, step=0.1)
intl_calls = st.slider("International Calls", 0, 20, 3)
intl_charge = st.number_input("International Charge", 0.0, 20.0, 2.7, step=0.1)
day_mins = st.number_input("Day Minutes", 0.0, 400.0, 180.0, step=0.5)
day_calls = st.slider("Day Calls", 0, 200, 100)
day_charge = st.number_input("Day Charge", 0.0, 70.0, 30.0, step=0.1)
eve_mins = st.number_input("Evening Minutes", 0.0, 400.0, 200.0, step=0.5)
eve_calls = st.slider("Evening Calls", 0, 200, 100)
eve_charge = st.number_input("Evening Charge", 0.0, 40.0, 17.0, step=0.1)
night_mins = st.number_input("Night Minutes", 0.0, 400.0, 200.0, step=0.5)
night_calls = st.slider("Night Calls", 0, 200, 100)
night_charge = st.number_input("Night Charge", 0.0, 20.0, 9.0, step=0.1)
customer_calls = st.slider("Customer Service Calls", 0, 20, 2)

# Build input DataFrame
input_df = pd.DataFrame([{
    "state": state,
    "account.length": account_length,
    "area.code": str(area_code),
    "voice.plan": voice_plan,
    "voice.messages": voice_messages,
    "intl.plan": intl_plan,
    "intl.mins": intl_mins,
    "intl.calls": intl_calls,
    "intl.charge": intl_charge,
    "day.mins": day_mins,
    "day.calls": day_calls,
    "day.charge": day_charge,
    "eve.mins": eve_mins,
    "eve.calls": eve_calls,
    "eve.charge": eve_charge,
    "night.mins": night_mins,
    "night.calls": night_calls,
    "night.charge": night_charge,
    "customer.calls": customer_calls
}])

# If feature_list provided with model bundle, ensure raw columns exist (neutral fill)
try:
    if feature_list:
        feature_list = [str(c) for c in feature_list]
        missing_raw = [c for c in feature_list if c not in input_df.columns]
        for c in missing_raw:
            input_df[c] = 0
except Exception:
    pass

# Prediction logic (pipeline-aware, pads transformed features if needed)
if st.button("Predict Churn"):
    try:
        if isinstance(model, Pipeline) and (preproc is not None) and (clf is not None):
            # Ensure required raw columns for preprocessor exist (best-effort)
            try:
                if hasattr(preproc, "feature_names_in_"):
                    raw_req = list(preproc.feature_names_in_)
                    for c in raw_req:
                        if c not in input_df.columns:
                            input_df[c] = 0
            except Exception:
                pass

            # Transform using preprocessor
            try:
                X_trans = preproc.transform(input_df)
            except Exception:
                # coerce object dtypes to str and retry
                for col in input_df.select_dtypes(include=["object"]).columns:
                    input_df[col] = input_df[col].astype(str)
                X_trans = preproc.transform(input_df)

            if hasattr(X_trans, "toarray"):
                X_trans = X_trans.toarray()
            X_trans = np.asarray(X_trans)
            n_trans = X_trans.shape[1]

            # classifier expected features
            clf_n = getattr(clf, "n_features_in_", None)
            if clf_n is None:
                clf_n = getattr(model, "n_features_in_", None)
            if clf_n is not None:
                clf_n = int(clf_n)

            # pad/truncate to match classifier expected dimension
            if clf_n is not None and clf_n > n_trans:
                diff = clf_n - n_trans
                X_pad = np.zeros((X_trans.shape[0], diff), dtype=X_trans.dtype)
                X_for_clf = np.hstack([X_trans, X_pad])
            elif clf_n is not None and clf_n < n_trans:
                X_for_clf = X_trans[:, :clf_n]
            else:
                X_for_clf = X_trans

            # predict using classifier
            pred = clf.predict(X_for_clf)[0]
            proba = None
            if hasattr(clf, "predict_proba"):
                try:
                    pr = clf.predict_proba(X_for_clf)
                    if pr is not None and pr.ndim == 2 and pr.shape[1] >= 2:
                        proba = float(pr[0, 1])
                    else:
                        proba = float(pr[0, 0])
                except Exception:
                    proba = None

        else:
            # Not a pipeline with preproc/clf — let model handle raw input
            pred = model.predict(input_df)[0]
            proba = None
            if hasattr(model, "predict_proba"):
                try:
                    pr = model.predict_proba(input_df)
                    if pr is not None and pr.ndim == 2 and pr.shape[1] >= 2:
                        proba = float(pr[0, 1])
                    else:
                        proba = float(pr[0, 0])
                except Exception:
                    proba = None

        # Display result
        if str(pred).lower() in ["1", "yes", "true"] or pred == 1:
            if proba is not None:
                st.error(f"Customer likely to churn! Probability: {proba:.2%}")
            else:
                st.error("Customer likely to churn!")
        else:
            if proba is not None:
                st.success(f"Customer not likely to churn. Probability: {proba:.2%}")
            else:
                st.success("Customer not likely to churn.")

        st.write("### Input Summary")
        st.dataframe(input_df)

    except Exception as e:
        st.error(f"Prediction failed: {e}")
