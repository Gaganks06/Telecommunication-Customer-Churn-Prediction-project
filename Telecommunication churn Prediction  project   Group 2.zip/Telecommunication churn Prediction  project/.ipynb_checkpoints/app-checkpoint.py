import streamlit as st
import pandas as pd
import joblib
from pathlib import Path
import numpy as np

# -------------------------------
# Streamlit Page Setup
# -------------------------------
st.set_page_config(page_title="Telecommunication Churn Prediction", layout="centered")
st.title("Telecommunication Customer Churn Prediction")

# -------------------------------
# Load Model
# -------------------------------
MODEL_PATH = Path("best_churn_model.pkl")

if not MODEL_PATH.exists():
    st.error("Model file 'best_churn_model.pkl' not found.")
    st.stop()

try:
    loaded_obj = joblib.load(MODEL_PATH)
except Exception as e:
    st.error(f"Error loading model file: {e}")
    st.stop()

# Accept either a dict bundle or pipeline directly
if isinstance(loaded_obj, dict):
    model = loaded_obj.get("model", None)
    feature_list = loaded_obj.get("feature_list", []) or []
    top_features = loaded_obj.get("top_features", None)
else:
    model = loaded_obj
    feature_list = []
    top_features = None

if model is None:
    st.error("No valid model found in the file.")
    st.stop()

# Ensure feature_list is a plain Python list (not a pandas Index)
try:
    if hasattr(feature_list, "tolist"):
        feature_list = list(feature_list.tolist())
    else:
        feature_list = list(feature_list)
except Exception:
    # fallback: empty list
    feature_list = list(feature_list) if isinstance(feature_list, (list, tuple)) else []

# -------------------------------
# Input Form
# -------------------------------
st.header("Enter Customer Details")

states = sorted([
    'AK', 'AL', 'AR', 'AZ', 'CA', 'CO', 'CT', 'DC', 'DE', 'FL', 'GA', 'HI', 'IA', 'ID', 'IL', 'IN',
    'KS', 'KY', 'LA', 'MA', 'MD', 'ME', 'MI', 'MN', 'MO', 'MS', 'MT', 'NC', 'ND', 'NE', 'NH', 'NJ',
    'NM', 'NV', 'NY', 'OH', 'OK', 'OR', 'PA', 'RI', 'SC', 'SD', 'TN', 'TX', 'UT', 'VA', 'VT', 'WA',
    'WI', 'WV', 'WY'
])

state = st.selectbox("State", states)
account_length = st.slider("Account Length (days)", 0, 250, 100)

# Use one area_code input only. These are the codes in your dataset.
area_code = st.selectbox("Area Code", ["408", "415", "510"])

voice_plan = st.selectbox("Voice Mail Plan", ["yes", "no"])
voice_messages = st.slider("Number of Voice Mail Messages", 0, 60, 10)
intl_plan = st.selectbox("International Plan", ["yes", "no"])
intl_mins = st.number_input("International Minutes", 0.0, 300.0, 10.0, step=0.1)
intl_calls = st.slider("International Calls", 0, 20, 3)
intl_charge = st.number_input("International Charge", 0.0, 20.0, 2.7, step=0.1)
day_mins = st.number_input("Day Minutes", 0.0, 400.0, 180.0, step=0.5)
day_calls = st.slider("Day Calls", 0, 200, 100)
day_charge = st.number_input("Day Charge", 0.0, 70.0, 30.0, step=0.1)
eve_mins = st.number_input("Evening Minutes", 0.0, 400.0, 200.0, step=0.5)
eve_calls = st.slider("Evening Calls", 0, 200, 100)
eve_charge = st.number_input("Evening Charge", 0.0, 40.0, 17.0, step=0.1)
night_mins = st.number_input("Night Minutes", 0.0, 400.0, 200.0, step=0.5)
night_calls = st.slider("Night Calls", 0, 200, 100)
night_charge = st.number_input("Night Charge", 0.0, 20.0, 9.0, step=0.1)
customer_calls = st.slider("Customer Service Calls", 0, 20, 2)

# -------------------------------
# Build input DataFrame (use scalar values)
# -------------------------------
input_df = pd.DataFrame([{
    "state": state,
    "account.length": account_length,
    "area.code": str(area_code),      # scalar string, not a list
    "voice.plan": voice_plan,
    "voice.messages": voice_messages,
    "intl.plan": intl_plan,
    "intl.mins": intl_mins,
    "intl.calls": intl_calls,
    "intl.charge": intl_charge,
    "day.mins": day_mins,
    "day.calls": day_calls,
    "day.charge": day_charge,
    "eve.mins": eve_mins,
    "eve.calls": eve_calls,
    "eve.charge": eve_charge,
    "night.mins": night_mins,
    "night.calls": night_calls,
    "night.charge": night_charge,
    "customer.calls": customer_calls
}])

# -------------------------------
# Align input columns with expected feature_list (if provided)
# -------------------------------
if feature_list:
    # ensure feature_list is list of strings
    feature_list = [str(c) for c in feature_list]

    # Add missing columns in one shot (avoid fragmentation)
    missing = [c for c in feature_list if c not in input_df.columns]
    if missing:
        missing_df = pd.DataFrame(0, index=input_df.index, columns=missing)
        input_df = pd.concat([input_df, missing_df], axis=1)

    # Reorder to match feature_list
    input_df = input_df.reindex(columns=feature_list, fill_value=0)

# If feature_list not available, we will pass raw input_df to pipeline and let pipeline preprocess

# -------------------------------
# Prediction
# -------------------------------
if st.button("Predict Churn"):
    try:
        # If loaded model is a pipeline, just pass raw input_df into it.
        if hasattr(model, "predict"):
            # If model is a dict-bundle where model is a pipeline, it's handled here too
            pred = model.predict(input_df)[0]

            proba = None
            if hasattr(model, "predict_proba"):
                proba = model.predict_proba(input_df)[0][1]

            if str(pred).lower() in ["1", "yes", "true"]:
                if proba is not None:
                    st.error(f"Customer likely to churn! Probability: {proba:.2%}")
                else:
                    st.error("Customer likely to churn!")
            else:
                if proba is not None:
                    st.success(f"Customer not likely to churn. Probability: {proba:.2%}")
                else:
                    st.success("Customer not likely to churn.")

            st.write("### Input Summary")
            st.dataframe(input_df)

        else:
            st.error("Loaded object is not a model with predict().")
    except Exception as e:
        st.error(f"Prediction failed: {e}")
